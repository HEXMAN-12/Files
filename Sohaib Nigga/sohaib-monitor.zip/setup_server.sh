#!/bin/bash

# Exit on error
set -e

echo "Setting up server services for monitoring..."

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root. Please use sudo."
    exit 1
fi

# Update package list
echo "Updating package list..."
apt update

# Install NGINX
echo "Installing NGINX..."
if ! command -v nginx &> /dev/null; then
    apt install -y nginx
    systemctl enable nginx
    systemctl start nginx
    echo "NGINX installed and started."
else
    echo "NGINX is already installed."
    systemctl enable nginx
    systemctl restart nginx
fi

# Install MySQL
echo "Installing MySQL..."
if ! command -v mysql &> /dev/null; then
    # Set up MySQL installation without interactive prompts
    export DEBIAN_FRONTEND=noninteractive
    debconf-set-selections <<< 'mysql-server mysql-server/root_password password rootpassword'
    debconf-set-selections <<< 'mysql-server mysql-server/root_password_again password rootpassword'
    
    apt install -y mysql-server
    systemctl enable mysql
    systemctl start mysql
    echo "MySQL installed and started."
    echo "Note: MySQL root password is set to 'rootpassword'"
else
    echo "MySQL is already installed."
    systemctl enable mysql
    systemctl restart mysql
fi

# Enable SSH server
echo "Enabling SSH server..."
if ! systemctl is-active --quiet ssh; then
    apt install -y openssh-server
    systemctl enable ssh
    systemctl start ssh
    echo "SSH server enabled and started."
else
    echo "SSH server is already running."
fi

# Ensure cron is running
echo "Ensuring cron service is running..."
systemctl enable cron
systemctl restart cron

# Check firewall and allow necessary services
if command -v ufw &> /dev/null; then
    echo "Configuring UFW firewall..."
    ufw --force enable
    ufw allow ssh
    ufw allow 'Nginx Full'
    ufw allow 3306  # MySQL
    echo "Firewall configured."
fi

# Create a simple nginx test page
echo "Creating test page for NGINX..."
cat > /var/www/html/health.html << 'EOF'
<!DOCTYPE html>
<html>
<head>
    <title>Server Health Check</title>
    <style>
        body { font-family: Arial, sans-serif; text-align: center; padding: 50px; }
        .status { color: green; font-size: 24px; }
    </style>
</head>
<body>
    <h1>Server Health Monitor</h1>
    <p class="status">✓ NGINX is running correctly!</p>
    <p>Server Time: <span id="time"></span></p>
    <script>
        document.getElementById('time').textContent = new Date().toLocaleString();
    </script>
</body>
</html>
EOF

echo ""
echo "Server services setup complete!"
echo "======================================="
echo "The following services are now installed and configured:"
echo "- NGINX (Web Server)"
echo "- MySQL (Database Server)"
echo "- SSH (Secure Shell)"
echo "- Cron (Task Scheduler)"
echo ""
echo "Test URLs:"
echo "- Default page: http://localhost/"
echo "- Health check: http://localhost/health.html"
echo ""
echo "MySQL Info:"
echo "- Root password: rootpassword"
echo "- Connect with: mysql -u root -p"
echo ""
echo "All services are enabled to start automatically on boot."
