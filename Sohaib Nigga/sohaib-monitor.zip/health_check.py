#!/usr/bin/env python3

import tkinter as tk
from tkinter import ttk, font
import psutil
import socket
import subprocess
import json
import time
import os
import threading
import datetime
from pathlib import Path

class ServerHealthChecker:
    def __init__(self, root):
        self.root = root
        self.root.title("Server Health Checker")
        self.root.geometry("800x600")
        self.root.minsize(700, 500)
        
        # Initialize metrics variables
        self.cpu_percent = 0
        self.memory_percent = 0
        self.disk_percent = 0
        self.internet_connected = False
        
        # Load configuration
        try:
            with open('config.json', 'r') as f:
                self.config = json.load(f)
        except FileNotFoundError:
            print("config.json not found. Using default configuration.")
            self.config = {
                "thresholds": {
                    "cpu": {"warning": 70, "critical": 85},
                    "memory": {"warning": 70, "critical": 85},
                    "disk": {"warning": 70, "critical": 90}
                },
                "services": ["nginx", "mysql", "ssh", "cron"]
            }
            
        # Create logs directory if it doesn't exist
        Path("logs").mkdir(exist_ok=True)
            
        # Set up UI
        self.setup_ui()
        
        # Start monitoring in a separate thread
        self.running = True
        self.thread = threading.Thread(target=self.update_metrics_loop)
        self.thread.daemon = True
        self.thread.start()
        
    def setup_ui(self):
        # Configure style and colors
        self.style = ttk.Style()
        self.style.theme_use('clam')
        
        # Define custom fonts - fallback to system fonts if Ubuntu not available
        try:
            default_font = font.nametofont("TkDefaultFont")
            default_font.configure(family="Ubuntu", size=10)
            heading_font = font.Font(family="Ubuntu", size=14, weight="bold")
            metric_font = font.Font(family="Ubuntu", size=12)
            value_font = font.Font(family="Ubuntu", size=12, weight="bold")
        except:
            # Fallback fonts
            heading_font = font.Font(size=14, weight="bold")
            metric_font = font.Font(size=12)
            value_font = font.Font(size=12, weight="bold")
        
        # Set up colors
        bg_color = "#2E3440"
        fg_color = "#ECEFF4"
        accent_color = "#88C0D0"
        
        self.root.configure(bg=bg_color)
        
        self.style.configure("TFrame", background=bg_color)
        self.style.configure("TLabel", background=bg_color, foreground=fg_color)
        self.style.configure("Header.TLabel", background=bg_color, foreground=accent_color, font=heading_font)
        self.style.configure("Metric.TLabel", background=bg_color, foreground=fg_color, font=metric_font)
        self.style.configure("Value.TLabel", background=bg_color, foreground=fg_color, font=value_font)

        # Create main container
        main_frame = ttk.Frame(self.root, padding="20")
        main_frame.pack(fill=tk.BOTH, expand=True)
        
        # Header
        header = ttk.Label(main_frame, text="Server Health Monitor", style="Header.TLabel")
        header.grid(row=0, column=0, columnspan=3, pady=(0, 20), sticky="w")
        
        # System metrics section
        system_frame = ttk.Frame(main_frame, padding="10")
        system_frame.grid(row=1, column=0, sticky="nsew", padx=(0, 10))
        
        ttk.Label(system_frame, text="System Metrics", style="Header.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        
        # Uptime
        ttk.Label(system_frame, text="Uptime:", style="Metric.TLabel").grid(row=1, column=0, sticky="w", pady=5)
        self.uptime_label = ttk.Label(system_frame, text="...", style="Value.TLabel")
        self.uptime_label.grid(row=1, column=1, sticky="e")
        
        # CPU Usage
        ttk.Label(system_frame, text="CPU Usage:", style="Metric.TLabel").grid(row=2, column=0, sticky="w", pady=5)
        self.cpu_label = ttk.Label(system_frame, text="0%", style="Value.TLabel")
        self.cpu_label.grid(row=2, column=1, sticky="e")
        
        # Memory Usage
        ttk.Label(system_frame, text="Memory Usage:", style="Metric.TLabel").grid(row=3, column=0, sticky="w", pady=5)
        self.memory_label = ttk.Label(system_frame, text="0%", style="Value.TLabel")
        self.memory_label.grid(row=3, column=1, sticky="e")
        
        # Disk Usage
        ttk.Label(system_frame, text="Disk Usage:", style="Metric.TLabel").grid(row=4, column=0, sticky="w", pady=5)
        self.disk_label = ttk.Label(system_frame, text="0%", style="Value.TLabel")
        self.disk_label.grid(row=4, column=1, sticky="e")
        
        # Internet Connectivity
        ttk.Label(system_frame, text="Internet:", style="Metric.TLabel").grid(row=5, column=0, sticky="w", pady=5)
        self.internet_frame = ttk.Frame(system_frame)
        self.internet_frame.grid(row=5, column=1, sticky="e")
        self.internet_indicator = tk.Canvas(self.internet_frame, width=15, height=15, bg=bg_color, highlightthickness=0)
        self.internet_indicator.pack(side=tk.LEFT)
        self.internet_indicator.create_oval(2, 2, 13, 13, fill="#D8DEE9", outline="")
        self.internet_label = ttk.Label(self.internet_frame, text="Checking...", style="Value.TLabel")
        self.internet_label.pack(side=tk.RIGHT)
        
        # Services section
        services_frame = ttk.Frame(main_frame, padding="10")
        services_frame.grid(row=1, column=1, sticky="nsew", padx=(0, 10))
        
        ttk.Label(services_frame, text="Services Status", style="Header.TLabel").grid(row=0, column=0, columnspan=2, sticky="w", pady=(0, 10))
        
        self.service_labels = {}
        self.service_indicators = {}
        
        for i, service in enumerate(self.config["services"]):
            ttk.Label(services_frame, text=f"{service}:", style="Metric.TLabel").grid(row=i+1, column=0, sticky="w", pady=5)
            
            service_frame = ttk.Frame(services_frame)
            service_frame.grid(row=i+1, column=1, sticky="e")
            
            indicator = tk.Canvas(service_frame, width=15, height=15, bg=bg_color, highlightthickness=0)
            indicator.pack(side=tk.LEFT, padx=(0, 5))
            indicator.create_oval(2, 2, 13, 13, fill="#D8DEE9", outline="")
            
            label = ttk.Label(service_frame, text="Checking...", style="Value.TLabel")
            label.pack(side=tk.RIGHT)
            
            self.service_labels[service] = label
            self.service_indicators[service] = indicator
        
        # Configure grid weights
        main_frame.columnconfigure(0, weight=1)
        main_frame.columnconfigure(1, weight=1)
        main_frame.rowconfigure(1, weight=1)
        
        # Status bar
        self.status_bar = ttk.Label(main_frame, text="Last updated: Never", style="TLabel")
        self.status_bar.grid(row=2, column=0, columnspan=3, sticky="w", pady=(10, 0))
        
    def get_uptime(self):
        try:
            if os.name == 'posix':  # Linux/Unix
                uptime_seconds = float(open('/proc/uptime').read().split()[0])
            else:  # Windows fallback
                import psutil
                uptime_seconds = time.time() - psutil.boot_time()
                
            days = int(uptime_seconds // 86400)
            hours = int((uptime_seconds % 86400) // 3600)
            minutes = int((uptime_seconds % 3600) // 60)
            
            uptime_str = ""
            if days > 0:
                uptime_str += f"{days}d "
            uptime_str += f"{hours}h {minutes}m"
            
            return uptime_str
        except:
            return "Unknown"
        
    def check_internet(self):
        try:
            socket.create_connection(("8.8.8.8", 53), timeout=3)
            return True
        except OSError:
            return False
            
    def check_service(self, service):
        try:
            result = subprocess.run(['systemctl', 'is-active', service], 
                                   stdout=subprocess.PIPE, 
                                   stderr=subprocess.PIPE,
                                   text=True, 
                                   timeout=3)
            return result.stdout.strip() == 'active'
        except (subprocess.SubprocessError, FileNotFoundError):
            return False
            
    def update_metrics(self):
        # Update uptime
        try:
            uptime = self.get_uptime()
            self.uptime_label.config(text=uptime)
        except Exception as e:
            self.uptime_label.config(text="Error")
            
        # Update CPU
        try:
            self.cpu_percent = psutil.cpu_percent(interval=0.1)
            self.cpu_label.config(text=f"{self.cpu_percent:.1f}%")
            
            # Set color based on threshold
            if self.cpu_percent >= self.config["thresholds"]["cpu"]["critical"]:
                self.cpu_label.config(foreground="#BF616A")  # Red
            elif self.cpu_percent >= self.config["thresholds"]["cpu"]["warning"]:
                self.cpu_label.config(foreground="#EBCB8B")  # Yellow
            else:
                self.cpu_label.config(foreground="#A3BE8C")  # Green
        except Exception as e:
            self.cpu_label.config(text="Error")
            self.cpu_percent = 0
            
        # Update memory
        try:
            memory = psutil.virtual_memory()
            self.memory_percent = memory.percent
            self.memory_label.config(text=f"{self.memory_percent:.1f}%")
            
            # Set color based on threshold
            if self.memory_percent >= self.config["thresholds"]["memory"]["critical"]:
                self.memory_label.config(foreground="#BF616A")  # Red
            elif self.memory_percent >= self.config["thresholds"]["memory"]["warning"]:
                self.memory_label.config(foreground="#EBCB8B")  # Yellow
            else:
                self.memory_label.config(foreground="#A3BE8C")  # Green
        except Exception as e:
            self.memory_label.config(text="Error")
            self.memory_percent = 0
            
        # Update disk
        try:
            disk = psutil.disk_usage('/')
            self.disk_percent = disk.percent
            self.disk_label.config(text=f"{self.disk_percent:.1f}%")
            
            # Set color based on threshold
            if self.disk_percent >= self.config["thresholds"]["disk"]["critical"]:
                self.disk_label.config(foreground="#BF616A")  # Red
            elif self.disk_percent >= self.config["thresholds"]["disk"]["warning"]:
                self.disk_label.config(foreground="#EBCB8B")  # Yellow
            else:
                self.disk_label.config(foreground="#A3BE8C")  # Green
        except Exception as e:
            self.disk_label.config(text="Error")
            self.disk_percent = 0
            
        # Update internet connectivity
        try:
            self.internet_connected = self.check_internet()
            self.internet_indicator.delete("all")
            if self.internet_connected:
                self.internet_indicator.create_oval(2, 2, 13, 13, fill="#A3BE8C", outline="")  # Green
                self.internet_label.config(text="Connected")
            else:
                self.internet_indicator.create_oval(2, 2, 13, 13, fill="#BF616A", outline="")  # Red
                self.internet_label.config(text="Disconnected")
        except Exception as e:
            self.internet_indicator.delete("all")
            self.internet_indicator.create_oval(2, 2, 13, 13, fill="#D8DEE9", outline="")  # Gray
            self.internet_label.config(text="Error")
            self.internet_connected = False
            
        # Update services
        for service in self.config["services"]:
            try:
                is_active = self.check_service(service)
                self.service_indicators[service].delete("all")
                if is_active:
                    self.service_indicators[service].create_oval(2, 2, 13, 13, fill="#A3BE8C", outline="")  # Green
                    self.service_labels[service].config(text="Running")
                else:
                    self.service_indicators[service].create_oval(2, 2, 13, 13, fill="#BF616A", outline="")  # Red
                    self.service_labels[service].config(text="Stopped")
            except Exception as e:
                self.service_indicators[service].delete("all")
                self.service_indicators[service].create_oval(2, 2, 13, 13, fill="#D8DEE9", outline="")  # Gray
                self.service_labels[service].config(text="Error")
                
        # Update status bar with current time
        current_time = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
        self.status_bar.config(text=f"Last updated: {current_time}")
        
        # Log metrics
        self.log_metrics()
                
    def log_metrics(self):
        try:
            timestamp = datetime.datetime.now().strftime('%Y-%m-%d %H:%M:%S')
            log_entry = f"{timestamp}, CPU: {self.cpu_percent:.1f}%, Memory: {self.memory_percent:.1f}%, Disk: {self.disk_percent:.1f}%, Internet: {'Connected' if self.internet_connected else 'Disconnected'}\n"
            
            with open("logs/health_log.txt", "a") as f:
                f.write(log_entry)
        except Exception as e:
            print(f"Error logging metrics: {e}")
    
    def update_metrics_loop(self):
        while self.running:
            try:
                self.root.after(0, self.update_metrics)
                time.sleep(10)  # Update every 10 seconds
            except Exception as e:
                print(f"Error in update loop: {e}")
                time.sleep(10)
    
    def on_close(self):
        self.running = False
        self.root.destroy()

if __name__ == "__main__":
    root = tk.Tk()
    app = ServerHealthChecker(root)
    root.protocol("WM_DELETE_WINDOW", app.on_close)
    root.mainloop()
