# Server Health Checker

A beautiful real-time server monitoring application with a modern GUI built using Python and Tkinter. Monitor your Ubuntu server's health metrics, service status, and system performance with live updates and color-coded alerts.

![Server Health Checker](https://img.shields.io/badge/Platform-Ubuntu-orange)
![Python](https://img.shields.io/badge/Python-3.6+-blue)
![License](https://img.shields.io/badge/License-MIT-green)

## 🌟 Features

### Real-time System Monitoring

- **System Uptime** - Track how long your server has been running
- **CPU Usage** - Monitor processor utilization with color-coded alerts
- **Memory Usage** - Track RAM consumption with threshold warnings
- **Disk Usage** - Monitor storage space with critical level alerts
- **Internet Connectivity** - Real-time connection status indicator
- **Service Status** - Monitor critical services (nginx, mysql, ssh, cron)

### Visual Indicators

- **Color-coded Metrics**: Green (normal), Yellow (warning), Red (critical)
- **Status Indicators**: Circular indicators for services and connectivity
- **Modern Dark Theme**: Beautiful dark interface with Nord color scheme
- **Responsive Layout**: Clean, organized interface that scales properly

### Data Logging

- **Automatic Logging**: Records metrics every 10 seconds
- **Historical Data**: Maintains log files in `logs/health_log.txt`
- **Timestamped Entries**: Each log entry includes date/time stamps

## 📋 Requirements

- **Operating System**: Ubuntu 18.04+ (or any Debian-based Linux)
- **Python**: Version 3.6 or higher
- **Privileges**: Root/sudo access for setup and service monitoring
- **Memory**: Minimum 512MB RAM
- **Storage**: At least 100MB free space

## 🚀 Quick Start

### 1. Download the Project

```bash
# Clone or download to your desired directory
cd /home/$(whoami)/Desktop
git clone https://github.com/yourusername/server-health-checker.git
cd server-health-checker

# Or if you downloaded manually:
cd server-health-checker
```

### 2. Run Application Setup

```bash
# Make setup script executable and run it
chmod +x setup_app.sh
sudo ./setup_app.sh
```

This script will:

- Install Python 3 and pip (if not installed)
- Install required Python packages (`psutil`)
- Install Tkinter GUI library
- Create necessary directories
- Set file permissions

### 3. (Optional) Install Server Services

```bash
# Make server setup script executable and run it
chmod +x setup_server.sh
sudo ./setup_server.sh
```

This script will install and configure:

- **NGINX** web server
- **MySQL** database server
- **SSH** server
- **Cron** service
- Basic firewall rules

### 4. Launch the Application

```bash
# Start the health monitor
python3 health_check.py
```

The GUI will open immediately and start displaying real-time metrics!

## ⚙️ Configuration

### Customize Monitoring Thresholds

Edit `config.json` to adjust warning and critical thresholds:

```json
{
  "thresholds": {
    "cpu": {
      "warning": 70, // Yellow at 70% CPU usage
      "critical": 85 // Red at 85% CPU usage
    },
    "memory": {
      "warning": 70, // Yellow at 70% memory usage
      "critical": 85 // Red at 85% memory usage
    },
    "disk": {
      "warning": 70, // Yellow at 70% disk usage
      "critical": 90 // Red at 90% disk usage
    }
  },
  "services": [
    "nginx", // Web server
    "mysql", // Database
    "ssh", // Secure shell
    "cron" // Task scheduler
  ]
}
```

### Add Custom Services

To monitor additional services, add them to the `services` array in `config.json`:

```json
"services": [
    "nginx",
    "mysql",
    "ssh",
    "cron",
    "docker",
    "postgresql",
    "redis-server"
]
```

## 📊 Understanding the Interface

### System Metrics Panel

- **Uptime**: Shows days, hours, and minutes since last boot
- **CPU Usage**: Percentage of processor utilization
- **Memory Usage**: Percentage of RAM being used
- **Disk Usage**: Percentage of root filesystem usage
- **Internet**: Connection status to external networks

### Services Status Panel

- **Green Circle**: Service is running
- **Red Circle**: Service is stopped
- **Gray Circle**: Service status unknown/error

### Color Coding

- **🟢 Green**: Normal operation (below warning threshold)
- **🟡 Yellow**: Warning level (above warning, below critical)
- **🔴 Red**: Critical level (above critical threshold)

## 📁 Project Structure

```
server-health-checker/
├── health_check.py      # Main application file
├── config.json          # Configuration settings
├── setup_app.sh         # Application setup script
├── setup_server.sh      # Server services setup script
├── README.md           # This documentation
└── logs/               # Auto-created log directory
    └── health_log.txt  # Health metrics log file
```

## 📝 Log Files

Health metrics are automatically logged to `logs/health_log.txt` every 10 seconds:

```
2024-01-15 14:30:45, CPU: 23.5%, Memory: 45.2%, Disk: 67.8%, Internet: Connected
2024-01-15 14:30:55, CPU: 25.1%, Memory: 46.0%, Disk: 67.8%, Internet: Connected
```

## 🔧 Troubleshooting

### GUI Won't Start

```bash
# Install Tkinter if missing
sudo apt-get update
sudo apt-get install python3-tk

# Check if Python 3 is installed
python3 --version
```

### Service Status Shows "Error"

```bash
# Run with sudo for service checking
sudo python3 health_check.py

# Check if systemctl is available
which systemctl
```

### Metrics Show "Error"

```bash
# Install psutil if missing
pip3 install psutil

# Check permissions
ls -la /proc/uptime
```

### Configuration File Missing

The application will create a default `config.json` if it's missing. You can also create it manually:

```bash
cat > config.json << 'EOF'
{
    "thresholds": {
        "cpu": {"warning": 70, "critical": 85},
        "memory": {"warning": 70, "critical": 85},
        "disk": {"warning": 70, "critical": 90}
    },
    "services": ["nginx", "mysql", "ssh", "cron"]
}
EOF
```

## 🔒 Security Notes

- The application requires sudo privileges to check service status
- MySQL is installed with a default root password: `rootpassword`
- SSH server is enabled by default - ensure you have proper access controls
- Firewall rules are configured automatically for essential services

## 🤝 Contributing

1. Fork the repository
2. Create a feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## 📄 License

This project is licensed under the MIT License - see the [LICENSE](LICENSE) file for details.

## 🙏 Acknowledgments

- Built with Python and Tkinter
- Uses psutil for system metrics
- Inspired by modern system monitoring tools
- Nord color scheme for beautiful UI

---

**Happy Monitoring!** 🖥️📊
