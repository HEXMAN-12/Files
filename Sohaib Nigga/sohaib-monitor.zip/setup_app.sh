#!/bin/bash

# Exit on error
set -e

echo "Setting up Server Health Checker dependencies..."

# Check if running as root
if [ "$(id -u)" -ne 0 ]; then
    echo "This script must be run as root. Please use sudo."
    exit 1
fi

# Update package list
echo "Updating package list..."
apt update

# Install Python 3 if not installed
if ! command -v python3 &> /dev/null; then
    echo "Python 3 not found. Installing..."
    apt install -y python3 python3-pip
else
    echo "Python 3 is already installed."
fi

# Install python3-tk if not installed
if ! dpkg -l | grep -q python3-tk; then
    echo "Installing Python Tkinter..."
    apt install -y python3-tk
else
    echo "Python Tkinter is already installed."
fi

# Install required Python packages
echo "Installing required Python packages..."
pip3 install psutil

# Create logs directory
mkdir -p logs
touch logs/health_log.txt
chmod 755 logs
chmod 644 logs/health_log.txt

# Make health_check.py executable
chmod +x health_check.py

echo "Setup complete! You can now run the application with:"
echo "python3 health_check.py"
